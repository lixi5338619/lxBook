import json
import random
import time
import requests


def get_sign_api(functionId, body):
    sign_api = 'http://127.0.0.1:8889/jd/sign'
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
    }
    data = {
        'functionId': functionId,
        'body': json.dumps(body, ensure_ascii=False)
    }
    res = requests.post(url=sign_api, headers=headers, data=data, timeout=30).json()
    if res['code'] == 0:
        return res['data']
    else:
        print(res['msg'])
        return -1

def randomString(e, flag=False):
    t = "0123456789abcdef"
    if flag: t = t.upper()
    n = [random.choice(t) for _ in range(e)]
    return ''.join(n)


def getCcFeedInfo():
    eid = randomString(16)
    body = {
        "categoryId": 118,
        "childActivityUrl": "openapp.jdmobile://virtual?params={\"category\":\"jump\",\"des\":\"couponCenter\"}",
        "eid": eid,
        "globalLat": "",
        "globalLng": "",
        "lat": "",
        "lng": "",
        "monitorRefer": "appClient",
        "monitorSource": "ccfeed_android_index_feed",
        "pageClickKey": "Coupons_GetCenter",
        "pageNum": 1,
        "pageSize": 20,
        "shshshfpb": ""
    }
    res = get_sign_api('getCcFeedInfo', body)
    url = f'https://api.m.jd.com?functionId=getCcFeedInfo{res}&eid={eid}'
    data = {
        "body": json.dumps(body)
    }
    res = requests.post(url=url, headers=headers, data=data, timeout=30).json()
    print(res)


def get_search():
    eid = randomString(16)
    ts = str(time.time()*1000)
    body = {"hdid":"JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=","ts":ts,"ridx":-1,"cipher":{"body":"oyTrZQHyHwvidQVyStesCISiSwPuZRTvc3DTZMS6StKsBMTrcxHfY2nvHXDzYXusEsSnSsmsZQV2aWDvaWHUYWviStesDzOsBMTvoRLlc2VuG291bxGsEsSmSsmsZxTlbxHPoRLfZRCsEsTQXzKmDySiSwdtGXTvYUvuStesDym0CJSiCzU0DIm1DtqnEISiSwdtJQP0StesCzGkDzuyDzc0SsmsZ2DCbwcsEsSnCJCkENOmDJSnSsmsaW1rZ2VzaXfvStf7SwdyaWHTbWcsEsS0DNH4DNG0SsmsbQvzdOvjZyS6StS2CRqyDtKsBMTib25xIW1xStesDNG0oNU5CsT9BMTfbxDvcxHLcxHfY2nvStesCISiSwvkc2VydPDtZW5vStesCISiSwvkc2VydQVuG291bxGsEsSmSsmsaXDNb3TyZWD0StesCISiSwfudsS6StL8YXLmbWPya2V0pRHpCtKnENUnCtUyDV9rcRLjYXThZXH8dRVfZ3Vrbwd8DJK5DtZpCP90ZW5tZW50XzLpCRmnDtU1CJK0ENS0Ssmsa2V5d29yZMS6SkoShEsZg+wKrkWGuos\/w+wYjkWkxkaSwMSiSwnrdQv0dWHvStesCzGkDzuyDzc0SsmsbQ9tYWnEdW0sEsSmSsmsbQ9kZ2v0dWHvStesCJOzBtqnCNUyCISiSw5vd01fZQHiZVHrZyS6StOsBMTkZXdWZXTzaW9kStesCySiSw9kZUTloO1lZMS6StOsBMTlcwvxbwPiU2VrcwDeStesCISiSw9yaWdkYWnJZWnvY3GsEsSnSsmscQPxZIS6StOsBMTmYWdvHW50cwPkY2UsEsSnSsmscQPxZXDfowUsEsSnCMSiSxLlc0PyZWPTZMS6StciDNOyBNC1DNUiDJY4CJusBMTmdwvuStesSsmsc2VrcwDeVwVyc2vlbuDlZQUsEsS5DtK1Ssmsc2Vtb25uIW5zZWHNb3VkdMS6StKsBMTzaQ93U2rlcPHrYsS6SxvvcySiSxDeb3dJdQ9yZVHrYsS6StOsBMTzdQ9tayS6StOspG=="},"ciphertype":5,"version":"1.2.0","appname":"com.jingdong.app.mall"}
    res = get_sign_api('search', body)
    print(res)
    url = f'https://api.m.jd.com/client.action?functionId=search&eid={eid}{res}'
    data = {
        "body": json.dumps(body)
    }
    res = requests.post(url=url, headers=headers, data=data, timeout=30).json()
    print(res)


if __name__ == '__main__':
    headers = {
        "cookie": 'whwswswws=JD012145b9TFfe370AnE165510480747806b5k46nMfFl2PG9mbgeh5HdM3T2HROgNqN7vwQOUU36y9V0OCEK_CkeE5_5BTdH8EiOzrsv3F6Zc91KWdAruL4SYb6EUYv3Mh7DA0g6zmKII1fw7ljv~e50Yf54Lsmmdbf8LTce_7X9nGBpc1jDYCtOe8KI61qtnLZEj5KIr70cBdhWnfyTM5WH-Adm1BGLJxWUf4D9gaG2qTGpxyr4FGvLc6RvxHnYtYoKj-rK9bM6tSdqSqIzAtifcBcYtytm0zhXfry9bnE9mByuJKBNBECt8hSfSfkBU;unionwsws={"devicefinger":"eidA9f6781212as88Y4pzcA+QGC9grbGMI\/8d\/GOK08cLWiXTmeC0hgwzjVQOCYrVuP6jTJvQI5IUXQWwH6n8Zn6uN\/e3rkiPJvusmS8W+1+oECHPY1w","jmafinger":"JD012145b9TFfe370AnE165510480747806b5k46nMfFl2PG9mbgeh5HdM3T2HROgNqN7vwQOUU36y9V0OCEK_CkeE5_5BTdH8EiOzrsv3F6Zc91KWdAruL4SYb6EUYv3Mh7DA0g6zmKII1fw7ljv~e50Yf54Lsmmdbf8LTce_7X9nGBpc1jDYCtOe8KI61qtnLZEj5KIr70cBdhWnfyTM5WH-Adm1BGLJxWUf4D9gaG2qTGpxyr4FGvLc6RvxHnYtYoKj-rK9bM6tSdqSqIzAtifcBcYtytm0zhXfry9bnE9mByuJKBNBECt8hSfSfkBU"};',
        "user-agent": "okhttp/3.12.1;jdmall;android;version/11.0.2;build/97565;",
        "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
    }
    print(getCcFeedInfo())
    print(get_search())


