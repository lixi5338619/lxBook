package com.spider.unidbgserver.service;

import com.sun.org.apache.xerces.internal.impl.xpath.XPath;

public interface JdService {

    public String getSign(String functionId, String uuid, String body);
}
