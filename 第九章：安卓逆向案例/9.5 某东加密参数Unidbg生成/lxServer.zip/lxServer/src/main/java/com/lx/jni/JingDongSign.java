package com.lx.jni;

import com.github.unidbg.AndroidEmulator;
import com.github.unidbg.Module;
import com.github.unidbg.linux.android.AndroidEmulatorBuilder;
import com.github.unidbg.linux.android.AndroidResolver;
import com.github.unidbg.linux.android.dvm.*;
import com.github.unidbg.linux.android.dvm.array.ByteArray;
import com.github.unidbg.linux.android.dvm.jni.ProxyDvmObject;
import com.github.unidbg.linux.android.dvm.wrapper.DvmInteger;
import com.github.unidbg.memory.Memory;
import sun.security.pkcs.PKCS7;
import sun.security.pkcs.ParsingException;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

// 京东APP 安卓10.1.4版本

public class JingDongSign extends AbstractJni {
    private final AndroidEmulator emulator;
    private final VM vm;
    private Module module;
    String rootPath = "C:\\Users\\feiyi\\Desktop\\AppTest\\";
    File apkFile = new File(rootPath+"京东.apk");
    File soFile = new File(rootPath+"libjdbitmapkit.so");

    // OtoB: Object to Bytes;
    private static byte[] OtoB(Object obj){
        try {
            ByteArrayOutputStream ByteStream = new ByteArrayOutputStream();
            ObjectOutputStream ObjectStream = new ObjectOutputStream(ByteStream);
            ObjectStream.writeObject(obj);
            ObjectStream.flush();
            byte[] newArray = ByteStream.toByteArray();
            ObjectStream.close();
            ByteStream.close();
            return newArray;
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    @Override
    public DvmObject<?> getStaticObjectField(BaseVM vm, DvmClass dvmClass, String signature) {
        switch (signature) {
            case "com/jingdong/common/utils/BitmapkitUtils->a:Landroid/app/Application;": {
                return vm.resolveClass("android/app/Activity", vm.resolveClass("android/content/ContextWrapper", vm.resolveClass("android/content/Context"))).newObject(signature);
            }
        }
        return super.getStaticObjectField(vm, dvmClass, signature);
    }

    @Override
    public DvmObject<?> callStaticObjectMethod(BaseVM vm, DvmClass dvmClass, String signature, VarArg varArg) {
        switch (signature) {
            case "com/jingdong/common/utils/BitmapkitZip->unZip(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B":
                String apkPath = apkFile.toString();
                StringObject directory = varArg.getObjectArg(1);
                StringObject filename = varArg.getObjectArg(2);
                if (apkPath.equals(apkPath) && "META-INF/".equals(directory.getValue()) && ".RSA".equals(filename.getValue())) {
                    byte[] data = vm.unzip("META-INF/JINGDONG.RSA");
                    return new ByteArray(vm, data);
                }
            case "com/jingdong/common/utils/BitmapkitZip->objectToBytes(Ljava/lang/Object;)[B":
                DvmObject<?> obj = varArg.getObjectArg(0);
                byte[] bytes = OtoB(obj.getValue());
                return new ByteArray(vm, bytes);
        }
        return super.callStaticObjectMethod(vm, dvmClass, signature, varArg);
    }

    @Override
    public DvmObject<?> getObjectField(BaseVM vm, DvmObject<?> dvmObject, String signature) {
        if ("android/app/ApplicationInfo->sourceDir:Ljava/lang/String;".equals(signature)) {
            return new StringObject(vm, soFile.toString());
        }
        if ("android/content/pm/ApplicationInfo->sourceDir:Ljava/lang/String;".equals(signature)) {
            return new StringObject(vm, soFile.toString());
        }
        return super.getObjectField(vm, dvmObject, signature);
    }

    @Override
    public DvmObject<?> newObject(BaseVM vm, DvmClass dvmClass, String signature, VarArg varArg) {
        if ("sun/security/pkcs/PKCS7-><init>([B)V".equals(signature)) {
            ByteArray array = varArg.getObjectArg(0);
            try {
                return vm.resolveClass("sun/security/pkcs/PKCS7").newObject(new PKCS7(array.getValue()));
            } catch (ParsingException e) {
                throw new IllegalStateException(e);
            }
        }

        return super.newObject(vm, dvmClass, signature, varArg);
    }

    @Override
    public DvmObject<?> callObjectMethod(BaseVM vm, DvmObject<?> dvmObject, String signature, VarArg varArg) {
        if ("sun/security/pkcs/PKCS7->getCertificates()[Ljava/security/cert/X509Certificate;".equals(signature)) {
            PKCS7 pkcs7 = (PKCS7) dvmObject.getValue();
            X509Certificate[] certificates = pkcs7.getCertificates();
            return ProxyDvmObject.createObject(vm, certificates);
        }
        return super.callObjectMethod(vm, dvmObject, signature, varArg);
    }

    @Override
    public DvmObject<?> newObjectV(BaseVM vm, DvmClass dvmClass, String signature, VaList vaList) {
        switch (signature) {
            case "java/lang/StringBuffer-><init>()V":
                return vm.resolveClass("java/lang/StringBuffer").newObject(new StringBuffer());
            case "java/lang/Integer-><init>(I)V":
                int value = vaList.getIntArg(0);
                return DvmInteger.valueOf(vm, value);
        }
        return super.newObjectV(vm, dvmClass, signature, vaList);
    }

    @Override
    public DvmObject<?> callObjectMethodV(BaseVM vm, DvmObject<?> dvmObject, String signature, VaList vaList) {
        switch (signature) {
            case "java/lang/StringBuffer->append(Ljava/lang/String;)Ljava/lang/StringBuffer;": {
                StringBuffer buffer = (StringBuffer) dvmObject.getValue();
                StringObject str = vaList.getObjectArg(0);
                buffer.append(str.getValue());
                return dvmObject;
            }
            case "java/lang/Integer->toString()Ljava/lang/String;":
                Integer it = (Integer) dvmObject.getValue();
                return new StringObject(vm, it.toString());
            case "java/lang/StringBuffer->toString()Ljava/lang/String;":
                StringBuffer buffer = (StringBuffer) dvmObject.getValue();
                return new StringObject(vm, buffer.toString());
        }
        return super.callObjectMethodV(vm, dvmObject, signature, vaList);
    }

    public JingDongSign() {
        emulator = AndroidEmulatorBuilder.for32Bit().build();
        final Memory memory = emulator.getMemory();
        memory.setLibraryResolver(new AndroidResolver(23));
        vm = emulator.createDalvikVM(apkFile);
        vm.setVerbose(false);
        vm.setJni(this);
        DalvikModule dm = vm.loadLibrary(soFile, true);
        module = dm.getModule();
        dm.callJNI_OnLoad(emulator);
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    emulator.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }));
    }

    public Map<String, String> get_sign(String types, String params){
        DvmClass BitmapkitUtils = vm.resolveClass("com/jingdong/common/utils/BitmapkitUtils");
        StringObject signs = BitmapkitUtils.callStaticJniMethodObject(emulator,"getSignFromJni()(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;",
                vm.resolveClass("android/app/Activity").newObject(null),
                types,
                params,
                "1ed2c3eaa237283d",
                "android",
                "10.1.4");
        String sign = signs.getValue();
        Map<String, String> result = new HashMap<>();
        result.put("sign", sign);
        return result;
    }

    public static void main(String[] args) {
        com.lx.jni.JingDongSign jd = new com.lx.jni.JingDongSign();
        String type = "search";
        String params = "{\"addrFilter\":\"1\",\"addressId\":\"0\",\"articleEssay\":\"1\",\"deviceidTail\":\"54\",\"exposedCount\":\"0\",\"frontExpids\":\"F_0_0\",\"gcAreaId\":\"20,1818,1826,12527\",\"gcLat\":\"24.998199\",\"gcLng\":\"108.567441\",\"imagesize\":{\"gridImg\":\"444x444\",\"listImg\":\"260x260\",\"longImg\":\"444x569\"},\"insertArticle\":\"1\",\"insertScene\":\"1\",\"insertedCount\":\"0\",\"isCorrect\":\"1\",\"keyword\":\"一体机\",\"latitude\":\"24.998199\",\"locAreaId\":\"\",\"locLat\":\"\",\"locLng\":\"\",\"localNum\":\"0\",\"longitude\":\"108.567441\",\"newMiddleTag\":\"1\",\"newVersion\":\"3\",\"oneBoxMod\":\"1\",\"orignalSearch\":\"1\",\"orignalSelect\":\"1\",\"page\":\"1\",\"pageEntrance\":\"1\",\"pagesize\":\"10\",\"posAreaId\":\"20,1818,1826,12527\",\"pvid\":\"\",\"searchVersionCode\":\"9398\",\"secondInsedCount\":\"0\",\"showShopTab\":\"yes\",\"showStoreTab\":\"1\",\"stock\":\"1\",\"ver\":\"110\"}";
        System.out.println(jd.get_sign(type,params));
    }

}