package com.lx.server;
import com.lx.jni.DouyinSign;
import com.lx.jni.JingDongSign;
import com.alibaba.fastjson.JSON;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@RequestMapping("/unidbg")
public class SignController {
    @Autowired(required = false)
    DouyinSign dyInstance;

    @Autowired(required = false)
    JingDongSign JDSign;


    @RequestMapping(value = "dySign", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public String dySign(@RequestParam("url") String url) {
        synchronized (this) {
            Map<String, String> result = dyInstance.crack(url);
            String jsonString = JSON.toJSONString(result);
            return jsonString;
        }
    }

    @RequestMapping(value = "jdSign", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public Object jdSign(HttpServletRequest request){
        String keyword=request.getParameter("keyword");
        JingDongSign jd = new JingDongSign();
        String type = "search";
        String params = "{\"addrFilter\":\"1\",\"addressId\":\"0\",\"articleEssay\":\"1\",\"deviceidTail\":\"54\",\"exposedCount\":\"0\",\"frontExpids\":\"F_0_0\",\"gcAreaId\":\"20,1818,1826,12527\",\"gcLat\":\"24.998199\",\"gcLng\":\"108.567441\",\"imagesize\":{\"gridImg\":\"444x444\",\"listImg\":\"260x260\",\"longImg\":\"444x569\"},\"insertArticle\":\"1\",\"insertScene\":\"1\",\"insertedCount\":\"0\",\"isCorrect\":\"1\",\"keyword\":\"LXGOOD\",\"latitude\":\"24.998199\",\"locAreaId\":\"\",\"locLat\":\"\",\"locLng\":\"\",\"localNum\":\"0\",\"longitude\":\"108.567441\",\"newMiddleTag\":\"1\",\"newVersion\":\"3\",\"oneBoxMod\":\"1\",\"orignalSearch\":\"1\",\"orignalSelect\":\"1\",\"page\":\"1\",\"pageEntrance\":\"1\",\"pagesize\":\"10\",\"posAreaId\":\"20,1818,1826,12527\",\"pvid\":\"\",\"searchVersionCode\":\"9398\",\"secondInsedCount\":\"0\",\"showShopTab\":\"yes\",\"showStoreTab\":\"1\",\"stock\":\"1\",\"ver\":\"110\"}";
        Map result = jd.get_sign(type,params);
        String jsonString = JSON.toJSONString(result);
        return jsonString;
    }
}
