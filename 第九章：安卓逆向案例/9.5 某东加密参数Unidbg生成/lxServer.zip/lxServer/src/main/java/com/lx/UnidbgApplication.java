package com.lx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnidbgApplication {
    public static void main(String[] args) {
        SpringApplication.run(UnidbgApplication.class, args);
    }
}
